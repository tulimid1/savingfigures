# savingfigures
Automatically saving figures in MATLAB and Python
